import re
import string

def printsomething():
	print("Hello from Python!")

# Function #1
# Open file, read contents, replace new line chars with nothing, and then build a freq dict
def readfile_buildfreqdict():
    with open(r"C:\Users\eusebius.ball_snhu\source\repos\CS210_Project_Three_Input_File.txt", "r") as fname:
        lines = fname.readlines()
        freq_dict = {}
        for line in lines:
            line = line.replace("\n", "")
            if line not in freq_dict.keys():
                freq_dict[line] = 1
            else:
                freq_dict[line] += 1
    # Print freq_dict in a certain format
    for key, value in freq_dict.items():
        print("Product: {} | Quantity: {}".format(key, value))
    return freq_dict

# Function #2
def displaygrocery_itemcount(item):
    with open(r"C:\Users\eusebius.ball_snhu\source\repos\frequency.dat", "r") as fname:
        lines = fname.readlines()
        for line in lines:
            line = line.replace("\n", "")
            new_line = line.split(" ")
            if new_line[0] == item:
                print(new_line[1])
            else:
                continue


# Write to frequency.dat file
def write_datfile():
    freq_dict = readfile_buildfreqdict()
    with open(r"C:\Users\eusebius.ball_snhu\source\repos\CS210_Project_Three_Input_File.txt", "w") as file_towrite:
        for key, value in freq_dict.items():
            file_towrite.write(f'{key} {value}\n')
    return file_towrite
