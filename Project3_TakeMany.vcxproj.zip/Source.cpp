#include <Python.h>
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <fstream>
#include <string>

using namespace std;

/*
Description:
	To call this function, simply pass the function name in Python that you wish to call.
Example:
	callProcedure("printsomething");
Output:
	Python will print on the screen: Hello from python!
Return:
	None
*/
void CallProcedure(string pName)
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("PythonCode");
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("PrintMe","Test");
Output:
	Python will print on the screen:
		You sent me: Test
Return:
	100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char* paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("doublevalue",5);
Return:
	25 is returned to the C++
*/
int callIntFunc(string proc, int param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(i)", param);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;

	return _PyLong_AsInt(presult);
}

void PrintMenuDisplay() {
	cout << "Please follow the menu instructions and enter a number 1 - 4" << endl;
	cout << "1 : Produce a list of all items purchased and their counts" << endl;
	cout << "2 : Produce the number of times the specified item was purchased (you will be prompted for the item name)" << endl;
	cout << "3 : Produce a text-based histogram of all items purchased and their counts represented by a histogram" << endl;
	cout << "4 : Exit the program" << endl;
}


int main()
{
	//CallProcedure("printsomething");
	//cout << callIntFunc("PrintMe", "House") << endl;
	//cout << callIntFunc("SquareValue", 2);
	// instantiate object for reading file
	ifstream inFS;
	inFS.open("frequency.dat");
	// data members for storing read data
	string productName = " ";
	int numSold = 0;

	// data members for user menu
	char userInput;
	string userInput2 = " ";
	bool flag = true;
	/*4 choices for user input:
	1: Calls 1st Python function that produces a list of ALL grocery items and number purchased
	2: Calls 2nd Python function that produces the SINGLE grocery item requested and the number purchased
	3: Performs C++ operation that produces histogram of all grocery items and number purchased (using #)
	4: Exit
	NOTE: Include input validation for other characters entered
	*/
	// read data in using ifstream object
	if (inFS.is_open()) {
		cout << "File is open! Proceed :)" << endl;
	}

	else {
		cout << "File is NOT open. Cannot Proceed :(" << endl;
		return -1;
	}

	PrintMenuDisplay();
	// user loop
	cin >> userInput;
	while (flag) {
		if (userInput == '1') {
			//Call Python function #1
			CallProcedure("readfile_buildfreqdict");
			//Producing a list of all items purchased in that day and their counts
			flag = false;
			return 1;
		}
		else if (userInput == '2') {
			cout << "Please enter the name of the grocery item to receive the number sold: " << endl;
			cin >> userInput2;
			cout << "You entered: " << userInput2 << endl;
			//Write .dat file
			ProcedureCall("write_datfile");
			//Call Python function #2
			callIntFunc("displaygrocery_itemcount", userInput2);
			//Produce the number specified item (input from user) was purchased in that day
			flag = false;
			return 2;
		}
		else if (userInput == '3') {
			//Use following C++ code to produce text-based histogram based on items 
			//and their respective counts purchased that day
			inFS >> productName;
			while (!inFS.fail()) {
				inFS >> numSold;
				//cout << "Received: " << productName << ", " << numSold << endl;
				cout << productName << " ";
				for (int i = 1; i <= numSold; ++i) {
					cout << '#';
				}
				cout << endl;
				inFS >> productName;
			}
			flag = false;
			return 3;
		}
		else if (userInput == '4') {
			cout << "Goodbye." << endl;
			flag = false;
			return 4;
		}
		else {
			cout << "Invalid Input, please enter 1, 2, 3 or 4" << endl;
			PrintMenuDisplay();
			cin >> userInput;
		}

	}


	return 0;
}